"use client";

import { useEffect, useState } from "react";
import { Match, Player, GoalEvent, CardEvent } from "@/lib/types";
import { listenPlayers, submitMatchResult } from "@/lib/firestore";
import { GlassCard } from "./UI";

export default function MatchResultForm({ match, onDone }: { match: Match; onDone?: () => void }) {
  const [players, setPlayers] = useState<Player[]>([]);
  const [homeScore, setHomeScore] = useState(match.homeScore ?? 0);
  const [awayScore, setAwayScore] = useState(match.awayScore ?? 0);
  const [goals, setGoals] = useState<GoalEvent[]>(match.goals || []);
  const [cards, setCards] = useState<CardEvent[]>(match.cards || []);
  const [motmId, setMotmId] = useState(match.manOfTheMatchId || "");
  const [lineup, setLineup] = useState<string[]>(match.lineup || []);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const u1 = listenPlayers((all) => {
      const teamPlayers = all.filter((p) => p.teamId === match.homeTeamId || p.teamId === match.awayTeamId);
      setPlayers(teamPlayers);
      // پیش‌فرض: در مسابقه‌ی جدید همه‌ی بازیکنان دو تیم به‌عنوان ترکیب انتخاب شوند
      setLineup((prev) => (prev.length ? prev : teamPlayers.map((p) => p.id)));
    });
    return u1;
  }, [match.homeTeamId, match.awayTeamId]);

  const toggleLineup = (playerId: string) => {
    setLineup((prev) => (prev.includes(playerId) ? prev.filter((id) => id !== playerId) : [...prev, playerId]));
  };

  const playerName = (id: string) => players.find((p) => p.id === id)?.name || "";

  const addGoal = () => {
    if (players.length === 0) return;
    setGoals([
      ...goals,
      { playerId: players[0].id, playerName: players[0].name, teamId: players[0].teamId }
    ]);
  };

  const updateGoal = (index: number, patch: Partial<GoalEvent>) => {
    setGoals((prev) =>
      prev.map((g, i) => {
        if (i !== index) return g;
        const next = { ...g, ...patch };
        if (patch.playerId) next.playerName = playerName(patch.playerId);
        if (patch.assistPlayerId) next.assistPlayerName = playerName(patch.assistPlayerId);
        if (patch.playerId) {
          const p = players.find((pl) => pl.id === patch.playerId);
          if (p) next.teamId = p.teamId;
        }
        return next;
      })
    );
  };

  const removeGoal = (index: number) => setGoals((prev) => prev.filter((_, i) => i !== index));

  const addCard = () => {
    if (players.length === 0) return;
    setCards([...cards, { playerId: players[0].id, playerName: players[0].name, teamId: players[0].teamId, type: "yellow" }]);
  };

  const updateCard = (index: number, patch: Partial<CardEvent>) => {
    setCards((prev) =>
      prev.map((c, i) => {
        if (i !== index) return c;
        const next = { ...c, ...patch };
        if (patch.playerId) {
          next.playerName = playerName(patch.playerId);
          const p = players.find((pl) => pl.id === patch.playerId);
          if (p) next.teamId = p.teamId;
        }
        return next;
      })
    );
  };

  const removeCard = (index: number) => setCards((prev) => prev.filter((_, i) => i !== index));

  const onSave = async () => {
    setSaving(true);
    try {
      await submitMatchResult(match.id, {
        homeScore,
        awayScore,
        goals,
        cards,
        lineup,
        manOfTheMatchId: motmId || undefined,
        manOfTheMatchName: motmId ? playerName(motmId) : undefined
      });
      onDone?.();
    } finally {
      setSaving(false);
    }
  };

  return (
    <GlassCard>
      <h3 className="font-bold text-gold-light mb-4">
        ثبت نتیجه: {match.homeTeamName} در برابر {match.awayTeamName}
      </h3>

      <div className="flex items-center justify-center gap-4 mb-6">
        <input
          type="number"
          className="input-field w-20 text-center"
          value={homeScore}
          min={0}
          onChange={(e) => setHomeScore(Number(e.target.value))}
        />
        <span className="text-slate-400">—</span>
        <input
          type="number"
          className="input-field w-20 text-center"
          value={awayScore}
          min={0}
          onChange={(e) => setAwayScore(Number(e.target.value))}
        />
      </div>

      <div className="mb-6">
        <p className="font-semibold text-sm text-slate-300 mb-2">
          👥 بازیکنان حاضر در مسابقه (برای شمارش «تعداد بازی»)
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1">
          {players.map((p) => (
            <label key={p.id} className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={lineup.includes(p.id)}
                onChange={() => toggleLineup(p.id)}
                className="accent-gold"
              />
              {p.name}
            </label>
          ))}
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <p className="font-semibold text-sm text-slate-300">⚽ گلزنان و پاس‌گل‌ها</p>
          <button onClick={addGoal} className="btn-outline text-xs py-1.5 px-3">افزودن گل</button>
        </div>
        {goals.map((g, i) => (
          <div key={i} className="grid grid-cols-[1fr_1fr_60px_32px] gap-2 mb-2">
            <select className="input-field text-sm" value={g.playerId} onChange={(e) => updateGoal(i, { playerId: e.target.value })}>
              {players.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <select
              className="input-field text-sm"
              value={g.assistPlayerId || ""}
              onChange={(e) => updateGoal(i, { assistPlayerId: e.target.value || undefined })}
            >
              <option value="">بدون پاس گل</option>
              {players.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <input
              type="number"
              placeholder="دقیقه"
              className="input-field text-sm"
              value={g.minute || ""}
              onChange={(e) => updateGoal(i, { minute: Number(e.target.value) })}
            />
            <button onClick={() => removeGoal(i)} className="text-red-400 text-sm">✕</button>
          </div>
        ))}
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <p className="font-semibold text-sm text-slate-300">🟨🟥 کارت‌ها</p>
          <button onClick={addCard} className="btn-outline text-xs py-1.5 px-3">افزودن کارت</button>
        </div>
        {cards.map((c, i) => (
          <div key={i} className="grid grid-cols-[1fr_90px_60px_32px] gap-2 mb-2">
            <select className="input-field text-sm" value={c.playerId} onChange={(e) => updateCard(i, { playerId: e.target.value })}>
              {players.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <select
              className="input-field text-sm"
              value={c.type}
              onChange={(e) => updateCard(i, { type: e.target.value as "yellow" | "red" })}
            >
              <option value="yellow">زرد</option>
              <option value="red">قرمز</option>
            </select>
            <input
              type="number"
              placeholder="دقیقه"
              className="input-field text-sm"
              value={c.minute || ""}
              onChange={(e) => updateCard(i, { minute: Number(e.target.value) })}
            />
            <button onClick={() => removeCard(i)} className="text-red-400 text-sm">✕</button>
          </div>
        ))}
      </div>

      <div className="mb-6">
        <p className="font-semibold text-sm text-slate-300 mb-2">🏅 بهترین بازیکن مسابقه</p>
        <select className="input-field" value={motmId} onChange={(e) => setMotmId(e.target.value)}>
          <option value="">انتخاب نشده</option>
          {players.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      <button onClick={onSave} disabled={saving} className="btn-gold w-full">
        {saving ? "در حال ثبت..." : "ثبت نتیجه"}
      </button>
    </GlassCard>
  );
}
