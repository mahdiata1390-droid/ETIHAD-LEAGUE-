export default function Footer() {
  return (
    <footer className="mt-16 mx-3 md:mx-6 mb-4">
      <div className="glass-card px-6 py-5 flex flex-col md:flex-row items-center justify-between gap-2 text-sm text-slate-400">
        <p>© {new Date().getFullYear()} لیگ اتحاد — تمامی حقوق محفوظ است.</p>
        <p className="gold-text font-semibold">Ettehad League</p>
      </div>
    </footer>
  );
}
