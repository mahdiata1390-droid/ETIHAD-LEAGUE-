"use client";

import Link from "next/link";
import { StandingRow } from "@/lib/types";
import { TeamLogo } from "./UI";

export default function StandingsTable({ rows }: { rows: StandingRow[] }) {
  return (
    <div className="glass-card overflow-x-auto p-0">
      <table className="w-full min-w-[720px] text-sm">
        <thead>
          <tr className="text-slate-400 border-b border-white/10">
            <th className="py-3 px-3 text-center">رتبه</th>
            <th className="py-3 px-3 text-right">تیم</th>
            <th className="py-3 px-2 text-center">بازی</th>
            <th className="py-3 px-2 text-center">برد</th>
            <th className="py-3 px-2 text-center">مساوی</th>
            <th className="py-3 px-2 text-center">باخت</th>
            <th className="py-3 px-2 text-center">گل زده</th>
            <th className="py-3 px-2 text-center">گل خورده</th>
            <th className="py-3 px-2 text-center">تفاضل</th>
            <th className="py-3 px-3 text-center">امتیاز</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr
              key={r.teamId}
              className={`border-b border-white/5 hover:bg-white/[0.04] transition-colors ${
                i < 3 ? "bg-gold/[0.03]" : ""
              }`}
            >
              <td className="py-3 px-3 text-center">
                <span
                  className={`inline-flex w-7 h-7 items-center justify-center rounded-full font-bold text-xs ${
                    i === 0
                      ? "bg-gold text-obsidian"
                      : i < 3
                      ? "bg-gold/20 text-gold-light"
                      : "text-slate-400"
                  }`}
                >
                  {i + 1}
                </span>
              </td>
              <td className="py-3 px-3">
                <Link href={`/teams/${r.teamId}`} className="flex items-center gap-2.5 hover:text-gold-light">
                  <TeamLogo src={r.logoUrl} alt={r.teamName} size={30} />
                  <span className="font-semibold">{r.teamName}</span>
                </Link>
              </td>
              <td className="py-3 px-2 text-center text-slate-300">{r.played}</td>
              <td className="py-3 px-2 text-center text-emerald-400">{r.won}</td>
              <td className="py-3 px-2 text-center text-slate-400">{r.drawn}</td>
              <td className="py-3 px-2 text-center text-red-400">{r.lost}</td>
              <td className="py-3 px-2 text-center text-slate-300">{r.goalsFor}</td>
              <td className="py-3 px-2 text-center text-slate-300">{r.goalsAgainst}</td>
              <td className="py-3 px-2 text-center text-slate-300">
                {r.goalDiff > 0 ? `+${r.goalDiff}` : r.goalDiff}
              </td>
              <td className="py-3 px-3 text-center font-extrabold gold-text text-base">{r.points}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
