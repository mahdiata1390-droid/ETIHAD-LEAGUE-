import Link from "next/link";
import { Match } from "@/lib/types";
import { TeamLogo, Badge } from "./UI";
import { toJalali } from "@/lib/date";

export default function MatchCard({ match }: { match: Match }) {
  const finished = match.status === "finished";
  return (
    <Link href={`/matches/${match.id}`}>
      <div className="glass-card p-4 hover:border-gold/50 transition-colors">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-slate-400">{toJalali(match.date)} — {match.time}</span>
          {finished ? (
            <Badge tone="green">پایان یافته</Badge>
          ) : match.status === "postponed" ? (
            <Badge tone="red">به تعویق افتاد</Badge>
          ) : (
            <Badge tone="blue">آینده</Badge>
          )}
        </div>
        <div className="flex items-center justify-between">
          <div className="flex flex-col items-center gap-1.5 w-1/3">
            <TeamLogo src={match.homeTeamLogo} alt={match.homeTeamName || ""} size={44} />
            <span className="text-xs font-semibold text-center line-clamp-1">{match.homeTeamName}</span>
          </div>

          <div className="text-center w-1/3">
            {finished ? (
              <div className="text-2xl font-extrabold gold-text">
                {match.homeScore} - {match.awayScore}
              </div>
            ) : (
              <div className="text-lg font-bold text-slate-400">VS</div>
            )}
          </div>

          <div className="flex flex-col items-center gap-1.5 w-1/3">
            <TeamLogo src={match.awayTeamLogo} alt={match.awayTeamName || ""} size={44} />
            <span className="text-xs font-semibold text-center line-clamp-1">{match.awayTeamName}</span>
          </div>
        </div>
        {match.venue && (
          <p className="text-center text-xs text-slate-500 mt-3">📍 {match.venue}</p>
        )}
      </div>
    </Link>
  );
}
