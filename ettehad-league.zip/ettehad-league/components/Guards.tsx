"use client";

import { ReactNode } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import { Spinner } from "./UI";

export function AdminOnly({ children }: { children: ReactNode }) {
  const { role, loading } = useAuth();
  const router = useRouter();

  if (loading) return <Spinner />;

  if (role !== "admin") {
    return (
      <div className="max-w-md mx-auto mt-16 glass-card p-8 text-center">
        <p className="font-bold text-lg mb-2">دسترسی محدود</p>
        <p className="text-sm text-slate-400 mb-5">
          این بخش فقط برای مدیر لیگ در دسترس است.
        </p>
        <button className="btn-gold" onClick={() => router.push("/login")}>
          ورود
        </button>
      </div>
    );
  }

  return <>{children}</>;
}

export function PlayerOnly({ children }: { children: ReactNode }) {
  const { role, loading } = useAuth();
  const router = useRouter();

  if (loading) return <Spinner />;

  if (role !== "player") {
    return (
      <div className="max-w-md mx-auto mt-16 glass-card p-8 text-center">
        <p className="font-bold text-lg mb-2">دسترسی محدود</p>
        <p className="text-sm text-slate-400 mb-5">
          این بخش فقط برای بازیکنانی که وارد حساب خود شده‌اند در دسترس است.
        </p>
        <button className="btn-gold" onClick={() => router.push("/login")}>
          ورود
        </button>
      </div>
    );
  }

  return <>{children}</>;
}
