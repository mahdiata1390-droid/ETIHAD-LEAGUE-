"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";

const links = [
  { href: "/", label: "خانه" },
  { href: "/standings", label: "جدول لیگ" },
  { href: "/teams", label: "تیم‌ها" },
  { href: "/players", label: "بازیکنان" },
  { href: "/matches", label: "مسابقات" },
  { href: "/scorers", label: "گلزنان" },
  { href: "/news", label: "اخبار" }
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { user, role, logout } = useAuth();

  return (
    <header className="sticky top-0 z-50 glass-card mx-3 mt-3 md:mx-6 md:mt-4 px-4 py-3">
      <div className="flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <span className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-light to-gold-dark flex items-center justify-center font-black text-obsidian shadow-gold-glow group-hover:scale-105 transition-transform">
            ا
          </span>
          <span className="font-extrabold text-lg gold-text">لیگ اتحاد</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                pathname === l.href
                  ? "text-gold bg-gold/10"
                  : "text-slate-300 hover:text-gold-light hover:bg-white/5"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          {role === "admin" && (
            <Link href="/admin/dashboard" className="btn-outline text-sm py-2 px-4">
              پنل مدیر
            </Link>
          )}
          {role === "player" && (
            <Link href="/player-panel" className="btn-outline text-sm py-2 px-4">
              پنل بازیکن
            </Link>
          )}
          {user ? (
            <button onClick={logout} className="btn-gold text-sm py-2 px-4">
              خروج
            </button>
          ) : (
            <Link href="/login" className="btn-gold text-sm py-2 px-4">
              ورود
            </Link>
          )}
        </div>

        <button
          className="md:hidden text-gold-light p-2"
          onClick={() => setOpen(!open)}
          aria-label="منو"
        >
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? (
              <path d="M6 6l12 12M18 6l-12 12" strokeLinecap="round" />
            ) : (
              <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
            )}
          </svg>
        </button>
      </div>

      {open && (
        <nav className="md:hidden mt-3 pt-3 border-t border-white/10 flex flex-col gap-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className={`px-3 py-2.5 rounded-lg text-sm font-medium ${
                pathname === l.href ? "text-gold bg-gold/10" : "text-slate-300"
              }`}
            >
              {l.label}
            </Link>
          ))}
          <div className="flex gap-2 mt-2">
            {role === "admin" && (
              <Link href="/admin/dashboard" className="btn-outline text-sm py-2 px-4 flex-1">
                پنل مدیر
              </Link>
            )}
            {role === "player" && (
              <Link href="/player-panel" className="btn-outline text-sm py-2 px-4 flex-1">
                پنل بازیکن
              </Link>
            )}
            {user ? (
              <button onClick={logout} className="btn-gold text-sm py-2 px-4 flex-1">
                خروج
              </button>
            ) : (
              <Link href="/login" className="btn-gold text-sm py-2 px-4 flex-1">
                ورود
              </Link>
            )}
          </div>
        </nav>
      )}
    </header>
  );
}
