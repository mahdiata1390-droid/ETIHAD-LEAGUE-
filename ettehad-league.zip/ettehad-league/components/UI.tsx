import Image from "next/image";
import { ReactNode } from "react";

export function GlassCard({
  children,
  className = ""
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`glass-card p-5 ${className}`}>{children}</div>;
}

export function TeamLogo({
  src,
  alt,
  size = 40
}: {
  src?: string;
  alt: string;
  size?: number;
}) {
  if (src) {
    return (
      <Image
        src={src}
        alt={alt}
        width={size}
        height={size}
        className="rounded-full object-cover border border-gold/30 bg-obsidian-2"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <div
      className="rounded-full border border-gold/30 bg-obsidian-2 flex items-center justify-center text-gold-light font-bold"
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {alt?.[0] || "؟"}
    </div>
  );
}

export function PlayerPhoto({
  src,
  alt,
  size = 56
}: {
  src?: string;
  alt: string;
  size?: number;
}) {
  if (src) {
    return (
      <Image
        src={src}
        alt={alt}
        width={size}
        height={size}
        className="rounded-xl object-cover border border-gold/30 bg-obsidian-2"
        style={{ width: size, height: size }}
      />
    );
  }
  return (
    <div
      className="rounded-xl border border-gold/30 bg-obsidian-2 flex items-center justify-center text-gold-light font-bold"
      style={{ width: size, height: size, fontSize: size * 0.35 }}
    >
      {alt?.[0] || "؟"}
    </div>
  );
}

export function Badge({ children, tone = "gold" }: { children: ReactNode; tone?: "gold" | "green" | "red" | "blue" }) {
  const tones: Record<string, string> = {
    gold: "bg-gold/15 text-gold-light border-gold/30",
    green: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    red: "bg-red-500/15 text-red-300 border-red-500/30",
    blue: "bg-blue-500/15 text-blue-300 border-blue-500/30"
  };
  return (
    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="glass-card p-10 text-center">
      <p className="text-lg font-bold text-slate-200 mb-1">{title}</p>
      {hint && <p className="text-sm text-slate-400">{hint}</p>}
    </div>
  );
}

export function Spinner() {
  return (
    <div className="flex justify-center py-10">
      <div className="w-8 h-8 rounded-full border-2 border-gold/30 border-t-gold animate-spin" />
    </div>
  );
}
