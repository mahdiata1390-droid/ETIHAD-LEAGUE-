import Link from "next/link";
import { Team, Player, NewsItem } from "@/lib/types";
import { TeamLogo, PlayerPhoto, Badge } from "./UI";
import { toJalali } from "@/lib/date";

export function TeamCard({ team }: { team: Team }) {
  return (
    <Link href={`/teams/${team.id}`}>
      <div className="glass-card p-5 flex flex-col items-center gap-3 hover:border-gold/50 hover:-translate-y-1 transition-all duration-300">
        <TeamLogo src={team.logoUrl} alt={team.name} size={72} />
        <div className="text-center">
          <p className="font-bold text-slate-100">{team.name}</p>
          {team.city && <p className="text-xs text-slate-400 mt-0.5">{team.city}</p>}
        </div>
      </div>
    </Link>
  );
}

export function PlayerCard({ player }: { player: Player }) {
  return (
    <Link href={`/players/${player.id}`}>
      <div className="glass-card p-4 flex items-center gap-4 hover:border-gold/50 transition-colors">
        <PlayerPhoto src={player.photoUrl} alt={player.name} size={56} />
        <div className="flex-1 min-w-0">
          <p className="font-bold text-slate-100 truncate">{player.name}</p>
          <p className="text-xs text-slate-400">{player.teamName} · {player.position}</p>
        </div>
        <span className="w-9 h-9 rounded-full bg-gold/10 border border-gold/30 flex items-center justify-center font-bold text-gold-light text-sm">
          {player.shirtNumber}
        </span>
      </div>
    </Link>
  );
}

export function NewsCard({ item }: { item: NewsItem }) {
  return (
    <div className="glass-card p-5">
      <div className="flex items-center justify-between mb-2">
        <Badge tone={item.type === "announcement" ? "red" : "gold"}>
          {item.type === "announcement" ? "اطلاعیه" : "خبر"}
        </Badge>
        <span className="text-xs text-slate-500">{toJalali(new Date(item.createdAt).toISOString())}</span>
      </div>
      {item.imageUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={item.imageUrl}
          alt={item.title}
          className="w-full h-40 object-cover rounded-xl mb-3 border border-white/10"
        />
      )}
      <h3 className="font-bold text-lg text-slate-100 mb-1">{item.title}</h3>
      <p className="text-sm text-slate-400 leading-relaxed whitespace-pre-line">{item.body}</p>
    </div>
  );
}
