import { format } from "date-fns-jalali";

/** تبدیل تاریخ میلادی (ISO) به تاریخ شمسی خوانا، مثل «۲۲ مرداد ۱۴۰۳» */
export function toJalali(isoDate: string): string {
  if (!isoDate) return "";
  try {
    const date = new Date(isoDate);
    if (isNaN(date.getTime())) return isoDate;
    return format(date, "d MMMM yyyy");
  } catch {
    return isoDate;
  }
}

export function toJalaliShort(isoDate: string): string {
  if (!isoDate) return "";
  try {
    const date = new Date(isoDate);
    if (isNaN(date.getTime())) return isoDate;
    return format(date, "yyyy/MM/dd");
  } catch {
    return isoDate;
  }
}
