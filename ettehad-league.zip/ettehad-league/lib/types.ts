export interface Team {
  id: string;
  name: string;
  logoUrl?: string;
  foundedYear?: number;
  city?: string;
  createdAt?: number;
}

export type PlayerPosition =
  | "دروازه‌بان"
  | "مدافع"
  | "هافبک"
  | "مهاجم";

export interface Player {
  id: string;
  name: string;
  photoUrl?: string;
  shirtNumber: number;
  position: PlayerPosition;
  teamId: string;
  teamName?: string;
  stats: {
    matches: number;
    goals: number;
    assists: number;
    yellowCards: number;
    redCards: number;
  };
  // برای ورود بازیکن به پنل خودش
  authUid?: string;
  createdAt?: number;
}

export type MatchStatus = "scheduled" | "finished" | "postponed";

export interface GoalEvent {
  playerId: string;
  playerName: string;
  teamId: string;
  minute?: number;
  assistPlayerId?: string;
  assistPlayerName?: string;
}

export interface CardEvent {
  playerId: string;
  playerName: string;
  teamId: string;
  type: "yellow" | "red";
  minute?: number;
}

export interface Match {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  homeTeamName?: string;
  awayTeamName?: string;
  homeTeamLogo?: string;
  awayTeamLogo?: string;
  date: string; // ISO date
  time: string; // HH:mm
  venue: string;
  status: MatchStatus;
  homeScore?: number;
  awayScore?: number;
  goals: GoalEvent[];
  cards: CardEvent[];
  lineup?: string[]; // شناسه بازیکنانی که در این مسابقه بازی کرده‌اند (برای شمارش «تعداد بازی»)
  manOfTheMatchId?: string;
  manOfTheMatchName?: string;
  createdAt?: number;
}

export interface NewsItem {
  id: string;
  title: string;
  body: string;
  imageUrl?: string;
  type: "news" | "announcement";
  createdAt: number;
}

export interface StandingRow {
  teamId: string;
  teamName: string;
  logoUrl?: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDiff: number;
  points: number;
}
