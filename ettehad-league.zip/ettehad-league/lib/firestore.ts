import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  runTransaction,
  Unsubscribe
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
import { db, storage } from "./firebase";
import { Match, NewsItem, Player, Team } from "./types";

// ---------- کمکی: آپلود عکس ----------
export async function uploadImage(file: File, path: string): Promise<string> {
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file);
  return getDownloadURL(storageRef);
}

export async function deleteImage(path: string) {
  try {
    await deleteObject(ref(storage, path));
  } catch {
    // اگر فایل وجود نداشت مشکلی نیست
  }
}

// ---------- تیم‌ها ----------
export function listenTeams(cb: (teams: Team[]) => void): Unsubscribe {
  const q = query(collection(db, "teams"), orderBy("name"));
  return onSnapshot(q, (snap) => {
    cb(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  });
}

export async function getTeam(id: string): Promise<Team | null> {
  const snap = await getDoc(doc(db, "teams", id));
  return snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as Team) : null;
}

export async function createTeam(data: Omit<Team, "id">) {
  return addDoc(collection(db, "teams"), { ...data, createdAt: Date.now() });
}

export async function updateTeam(id: string, data: Partial<Team>) {
  return updateDoc(doc(db, "teams", id), data as any);
}

export async function deleteTeam(id: string) {
  return deleteDoc(doc(db, "teams", id));
}

// ---------- بازیکنان ----------
export function listenPlayers(cb: (players: Player[]) => void, teamId?: string): Unsubscribe {
  const base = collection(db, "players");
  const q = teamId ? query(base, where("teamId", "==", teamId)) : query(base, orderBy("name"));
  return onSnapshot(q, (snap) => {
    cb(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  });
}

export async function getPlayer(id: string): Promise<Player | null> {
  const snap = await getDoc(doc(db, "players", id));
  return snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as Player) : null;
}

const emptyStats = { matches: 0, goals: 0, assists: 0, yellowCards: 0, redCards: 0 };

export async function createPlayer(data: Omit<Player, "id" | "stats">) {
  return addDoc(collection(db, "players"), {
    ...data,
    stats: emptyStats,
    createdAt: Date.now()
  });
}

export async function updatePlayer(id: string, data: Partial<Player>) {
  return updateDoc(doc(db, "players", id), data as any);
}

export async function deletePlayer(id: string) {
  return deleteDoc(doc(db, "players", id));
}

// ---------- مسابقات ----------
export function listenMatches(cb: (matches: Match[]) => void): Unsubscribe {
  const q = query(collection(db, "matches"), orderBy("date", "desc"));
  return onSnapshot(q, (snap) => {
    cb(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  });
}

export async function getMatch(id: string): Promise<Match | null> {
  const snap = await getDoc(doc(db, "matches", id));
  return snap.exists() ? ({ id: snap.id, ...(snap.data() as any) } as Match) : null;
}

export async function createMatch(data: Omit<Match, "id" | "goals" | "cards" | "status">) {
  return addDoc(collection(db, "matches"), {
    ...data,
    status: "scheduled",
    goals: [],
    cards: [],
    createdAt: Date.now()
  });
}

export async function updateMatchSchedule(id: string, data: Partial<Match>) {
  return updateDoc(doc(db, "matches", id), data as any);
}

export async function deleteMatch(id: string) {
  return deleteDoc(doc(db, "matches", id));
}

/**
 * ثبت یا ویرایش نتیجه‌ی مسابقه به همراه گلزنان، پاس‌گل‌ها، کارت‌ها و بهترین بازیکن.
 * آمار بازیکنان (گل، پاس گل، کارت، تعداد بازی) به صورت خودکار در یک تراکنش به‌روزرسانی می‌شود.
 * جدول لیگ نیازی به ذخیره‌سازی جداگانه ندارد چون همیشه زنده از روی matches محاسبه می‌شود.
 */
export async function submitMatchResult(
  matchId: string,
  result: Pick<Match, "homeScore" | "awayScore" | "goals" | "cards" | "manOfTheMatchId" | "manOfTheMatchName" | "lineup">
) {
  await runTransaction(db, async (tx) => {
    const matchRef = doc(db, "matches", matchId);
    const matchSnap = await tx.get(matchRef);
    if (!matchSnap.exists()) throw new Error("مسابقه یافت نشد");
    const prevMatch = matchSnap.data() as Match;
    const wasFinished = prevMatch.status === "finished";

    // جمع‌آوری بازیکنان درگیر در نسخه‌ی قبلی و جدید برای محاسبه‌ی صحیح آمار
    const involvedPlayerIds = new Set<string>();
    (prevMatch.goals || []).forEach((g) => {
      involvedPlayerIds.add(g.playerId);
      if (g.assistPlayerId) involvedPlayerIds.add(g.assistPlayerId);
    });
    (prevMatch.cards || []).forEach((c) => involvedPlayerIds.add(c.playerId));
    (prevMatch.lineup || []).forEach((pid) => involvedPlayerIds.add(pid));
    result.goals.forEach((g) => {
      involvedPlayerIds.add(g.playerId);
      if (g.assistPlayerId) involvedPlayerIds.add(g.assistPlayerId);
    });
    result.cards.forEach((c) => involvedPlayerIds.add(c.playerId));
    (result.lineup || []).forEach((pid) => involvedPlayerIds.add(pid));

    const playerRefs = new Map<string, ReturnType<typeof doc>>();
    for (const pid of involvedPlayerIds) {
      playerRefs.set(pid, doc(db, "players", pid));
    }
    const playerSnaps = new Map<string, any>();
    for (const [pid, ref] of playerRefs) {
      const s = await tx.get(ref);
      if (s.exists()) playerSnaps.set(pid, s.data());
    }

    // اگر قبلاً نتیجه ثبت شده بود، اول آمار قبلی را برمی‌گردانیم (کم می‌کنیم)
    if (wasFinished) {
      (prevMatch.goals || []).forEach((g) => {
        const p = playerSnaps.get(g.playerId);
        if (p) p.stats.goals = Math.max(0, (p.stats.goals || 0) - 1);
        if (g.assistPlayerId) {
          const a = playerSnaps.get(g.assistPlayerId);
          if (a) a.stats.assists = Math.max(0, (a.stats.assists || 0) - 1);
        }
      });
      (prevMatch.cards || []).forEach((c) => {
        const p = playerSnaps.get(c.playerId);
        if (p) {
          if (c.type === "yellow") p.stats.yellowCards = Math.max(0, (p.stats.yellowCards || 0) - 1);
          else p.stats.redCards = Math.max(0, (p.stats.redCards || 0) - 1);
        }
      });
      (prevMatch.lineup || []).forEach((pid) => {
        const p = playerSnaps.get(pid);
        if (p) p.stats.matches = Math.max(0, (p.stats.matches || 0) - 1);
      });
    }

    // اعمال آمار جدید
    result.goals.forEach((g) => {
      const p = playerSnaps.get(g.playerId);
      if (p) p.stats.goals = (p.stats.goals || 0) + 1;
      if (g.assistPlayerId) {
        const a = playerSnaps.get(g.assistPlayerId);
        if (a) a.stats.assists = (a.stats.assists || 0) + 1;
      }
    });
    result.cards.forEach((c) => {
      const p = playerSnaps.get(c.playerId);
      if (p) {
        if (c.type === "yellow") p.stats.yellowCards = (p.stats.yellowCards || 0) + 1;
        else p.stats.redCards = (p.stats.redCards || 0) + 1;
      }
    });
    (result.lineup || []).forEach((pid) => {
      const p = playerSnaps.get(pid);
      if (p) p.stats.matches = (p.stats.matches || 0) + 1;
    });

    // ثبت این تراکنش را بنویس
    for (const [pid, ref] of playerRefs) {
      const data = playerSnaps.get(pid);
      if (data) tx.update(ref, { stats: data.stats });
    }

    tx.update(matchRef, {
      status: "finished",
      homeScore: result.homeScore,
      awayScore: result.awayScore,
      goals: result.goals,
      cards: result.cards,
      lineup: result.lineup || [],
      manOfTheMatchId: result.manOfTheMatchId || null,
      manOfTheMatchName: result.manOfTheMatchName || null
    });
  });
}

/** افزایش تعداد بازی برای بازیکنانی که در ترکیب مسابقه حضور داشتند (اختیاری، هنگام ثبت اولیه‌ی نتیجه فراخوانی شود) */
export async function incrementMatchesPlayed(playerIds: string[]) {
  await runTransaction(db, async (tx) => {
    for (const pid of playerIds) {
      const ref = doc(db, "players", pid);
      const snap = await tx.get(ref);
      if (snap.exists()) {
        const data = snap.data() as any;
        tx.update(ref, { "stats.matches": (data.stats?.matches || 0) + 1 });
      }
    }
  });
}

// ---------- اتصال حساب کاربری بازیکن ----------
// چون Firebase در سمت کلاینت اجازه‌ی ساخت حساب برای شخص دیگر را نمی‌دهد،
// روند کار این‌طور است: ۱) مدیر یک حساب Email/Password برای بازیکن در Firebase
// Console (Authentication > Users) می‌سازد، ۲) UID ساخته‌شده را اینجا به بازیکن متصل می‌کند.
export async function linkPlayerAccount(authUid: string, playerId: string) {
  const { doc: docRef, setDoc } = await import("firebase/firestore");
  await setDoc(docRef(db, "playerLinks", authUid), { playerId });
  await updateDoc(doc(db, "players", playerId), { authUid });
}

export async function unlinkPlayerAccount(authUid: string, playerId: string) {
  await deleteDoc(doc(db, "playerLinks", authUid));
  await updateDoc(doc(db, "players", playerId), { authUid: null });
}

// ---------- اخبار ----------
export function listenNews(cb: (items: NewsItem[]) => void): Unsubscribe {
  const q = query(collection(db, "news"), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snap) => {
    cb(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
  });
}

export async function createNews(data: Omit<NewsItem, "id" | "createdAt">) {
  return addDoc(collection(db, "news"), { ...data, createdAt: Date.now() });
}

export async function deleteNews(id: string) {
  return deleteDoc(doc(db, "news", id));
}
