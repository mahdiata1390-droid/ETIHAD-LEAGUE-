"use client";

import { useEffect, useState } from "react";
import { listenNews } from "@/lib/firestore";
import { NewsItem } from "@/lib/types";
import { NewsCard } from "@/components/Cards";
import { Spinner, EmptyState } from "@/components/UI";

export default function NewsPage() {
  const [news, setNews] = useState<NewsItem[] | null>(null);

  useEffect(() => listenNews(setNews), []);

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">اخبار و اطلاعیه‌ها</h1>
      {news === null ? (
        <Spinner />
      ) : news.length === 0 ? (
        <EmptyState title="خبری منتشر نشده" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {news.map((n) => (
            <NewsCard key={n.id} item={n} />
          ))}
        </div>
      )}
    </div>
  );
}
