"use client";

import { useEffect, useState } from "react";
import { PlayerOnly } from "@/components/Guards";
import { useAuth } from "@/contexts/AuthContext";
import { getPlayer, listenMatches } from "@/lib/firestore";
import { Player, Match } from "@/lib/types";
import { PlayerPhoto, GlassCard, Spinner, EmptyState } from "@/components/UI";
import MatchCard from "@/components/MatchCard";

export default function PlayerPanelPage() {
  return (
    <PlayerOnly>
      <PlayerPanelContent />
    </PlayerOnly>
  );
}

function PlayerPanelContent() {
  const { playerId } = useAuth();
  const [player, setPlayer] = useState<Player | null | undefined>(undefined);
  const [matches, setMatches] = useState<Match[] | null>(null);

  useEffect(() => {
    if (!playerId) return;
    getPlayer(playerId).then(setPlayer);
    const unsub = listenMatches(setMatches);
    return unsub;
  }, [playerId]);

  if (player === undefined || matches === null) return <Spinner />;
  if (player === null) return <EmptyState title="پروفایل بازیکن یافت نشد" />;

  const s = player.stats;
  const myMatches = matches
    .filter((m) => m.status === "finished" && (m.homeTeamId === player.teamId || m.awayTeamId === player.teamId))
    .slice(0, 6);

  return (
    <div className="px-3 md:px-6 py-8 max-w-3xl mx-auto">
      <h1 className="section-title mb-6">پنل بازیکن</h1>

      <div className="glass-panel p-8 flex flex-col sm:flex-row items-center gap-6 mb-8 fade-up">
        <PlayerPhoto src={player.photoUrl} alt={player.name} size={100} />
        <div className="text-center sm:text-right flex-1">
          <h2 className="text-2xl font-extrabold gold-text mb-1">{player.name}</h2>
          <p className="text-slate-400 text-sm">{player.teamName} · {player.position} · پیراهن #{player.shirtNumber}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-10">
        <GlassCard className="text-center"><p className="text-2xl font-extrabold">{s.matches}</p><p className="text-xs text-slate-400 mt-1">بازی</p></GlassCard>
        <GlassCard className="text-center"><p className="text-2xl font-extrabold gold-text">{s.goals}</p><p className="text-xs text-slate-400 mt-1">گل</p></GlassCard>
        <GlassCard className="text-center"><p className="text-2xl font-extrabold">{s.assists}</p><p className="text-xs text-slate-400 mt-1">پاس گل</p></GlassCard>
        <GlassCard className="text-center"><p className="text-2xl font-extrabold text-yellow-400">{s.yellowCards}</p><p className="text-xs text-slate-400 mt-1">کارت زرد</p></GlassCard>
        <GlassCard className="text-center"><p className="text-2xl font-extrabold text-red-400">{s.redCards}</p><p className="text-xs text-slate-400 mt-1">کارت قرمز</p></GlassCard>
      </div>

      <h2 className="section-title mb-4">آخرین مسابقات تیم شما</h2>
      {myMatches.length === 0 ? (
        <EmptyState title="مسابقه‌ای ثبت نشده" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {myMatches.map((m) => <MatchCard key={m.id} match={m} />)}
        </div>
      )}

      <p className="text-xs text-slate-500 text-center mt-10">
        شما فقط می‌توانید اطلاعات خود را مشاهده کنید. برای هرگونه تغییر با مدیر لیگ تماس بگیرید.
      </p>
    </div>
  );
}
