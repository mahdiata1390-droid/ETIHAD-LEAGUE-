"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      router.push("/");
    } catch {
      setError("ایمیل یا رمز عبور اشتباه است.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 px-4">
      <div className="glass-panel p-8 fade-up">
        <h1 className="section-title text-center mb-1">ورود به حساب</h1>
        <p className="text-center text-sm text-slate-400 mb-6">
          ویژه‌ی مدیر لیگ و بازیکنان ثبت‌نام‌شده
        </p>
        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <div>
            <label className="text-sm text-slate-300 mb-1.5 block">ایمیل</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input-field"
              placeholder="example@email.com"
              dir="ltr"
            />
          </div>
          <div>
            <label className="text-sm text-slate-300 mb-1.5 block">رمز عبور</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="input-field"
              placeholder="••••••••"
              dir="ltr"
            />
          </div>
          {error && <p className="text-red-400 text-sm text-center">{error}</p>}
          <button type="submit" disabled={loading} className="btn-gold mt-2">
            {loading ? "در حال ورود..." : "ورود"}
          </button>
        </form>
        <p className="text-xs text-slate-500 text-center mt-5">
          حساب بازیکنان توسط مدیر لیگ ساخته می‌شود.
        </p>
      </div>
    </div>
  );
}
