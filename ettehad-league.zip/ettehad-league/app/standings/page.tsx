"use client";

import { useEffect, useState } from "react";
import { listenTeams, listenMatches } from "@/lib/firestore";
import { computeStandings } from "@/lib/standings";
import { Team, Match } from "@/lib/types";
import StandingsTable from "@/components/StandingsTable";
import { Spinner, EmptyState } from "@/components/UI";

export default function StandingsPage() {
  const [teams, setTeams] = useState<Team[] | null>(null);
  const [matches, setMatches] = useState<Match[] | null>(null);

  useEffect(() => {
    const u1 = listenTeams(setTeams);
    const u2 = listenMatches(setMatches);
    return () => {
      u1();
      u2();
    };
  }, []);

  const loading = teams === null || matches === null;

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">جدول لیگ اتحاد</h1>
      {loading ? (
        <Spinner />
      ) : teams!.length === 0 ? (
        <EmptyState title="هنوز تیمی ثبت نشده" hint="پس از افزودن تیم‌ها، جدول اینجا نمایش داده می‌شود." />
      ) : (
        <StandingsTable rows={computeStandings(teams!, matches!)} />
      )}
    </div>
  );
}
