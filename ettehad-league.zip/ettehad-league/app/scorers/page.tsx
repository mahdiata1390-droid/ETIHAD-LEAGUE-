"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { listenPlayers } from "@/lib/firestore";
import { Player } from "@/lib/types";
import { PlayerPhoto, Spinner, EmptyState } from "@/components/UI";

export default function ScorersPage() {
  const [players, setPlayers] = useState<Player[] | null>(null);

  useEffect(() => listenPlayers(setPlayers), []);

  const sorted = (players || [])
    .filter((p) => p.stats.goals > 0)
    .sort((a, b) => b.stats.goals - a.stats.goals);

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">جدول گلزنان</h1>
      {players === null ? (
        <Spinner />
      ) : sorted.length === 0 ? (
        <EmptyState title="هنوز گلی ثبت نشده" />
      ) : (
        <div className="glass-card overflow-hidden p-0">
          {sorted.map((p, i) => (
            <Link key={p.id} href={`/players/${p.id}`}>
              <div className="flex items-center gap-4 px-4 py-3.5 border-b border-white/5 hover:bg-white/[0.04] transition-colors">
                <span
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                    i === 0 ? "bg-gold text-obsidian" : i < 3 ? "bg-gold/20 text-gold-light" : "text-slate-400"
                  }`}
                >
                  {i + 1}
                </span>
                <PlayerPhoto src={p.photoUrl} alt={p.name} size={44} />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-slate-100 truncate">{p.name}</p>
                  <p className="text-xs text-slate-400">{p.teamName}</p>
                </div>
                <span className="text-xl font-extrabold gold-text">{p.stats.goals}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
