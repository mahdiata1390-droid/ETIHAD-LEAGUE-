import type { Metadata, Viewport } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/contexts/AuthContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const vazir = Vazirmatn({
  subsets: ["arabic"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-vazir",
  display: "swap"
});

export const metadata: Metadata = {
  title: "لیگ اتحاد | Ettehad League",
  description: "پلتفرم مدیریت لیگ فوتبال محلی اتحاد — جدول، تیم‌ها، بازیکنان و مسابقات",
  manifest: "/manifest.json",
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/apple-touch-icon.png"
  }
};

export const viewport: Viewport = {
  themeColor: "#0a0e17",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={vazir.variable}>
      <body className="font-vazir bg-navy-gradient bg-fixed min-h-screen text-slate-100 antialiased">
        <div className="fixed inset-0 -z-10 bg-radial-glow pointer-events-none" />
        <AuthProvider>
          <Navbar />
          <main className="min-h-[calc(100vh-140px)]">{children}</main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}
