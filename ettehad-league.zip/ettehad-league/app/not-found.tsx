import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="glass-panel p-10 text-center max-w-sm">
        <div className="text-4xl mb-4 gold-text font-extrabold">۴۰۴</div>
        <h1 className="font-bold text-lg mb-2">صفحه یافت نشد</h1>
        <p className="text-slate-400 text-sm mb-6">صفحه‌ی مورد نظر شما وجود ندارد یا جابه‌جا شده است.</p>
        <Link href="/" className="btn-gold">بازگشت به خانه</Link>
      </div>
    </div>
  );
}
