"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { listenMatches, listenNews } from "@/lib/firestore";
import { Match, NewsItem } from "@/lib/types";
import MatchCard from "@/components/MatchCard";
import { NewsCard } from "@/components/Cards";
import { EmptyState, Spinner } from "@/components/UI";

export default function HomePage() {
  const [matches, setMatches] = useState<Match[] | null>(null);
  const [news, setNews] = useState<NewsItem[] | null>(null);

  useEffect(() => {
    const unsub1 = listenMatches(setMatches);
    const unsub2 = listenNews(setNews);
    return () => {
      unsub1();
      unsub2();
    };
  }, []);

  const results = (matches || []).filter((m) => m.status === "finished").slice(0, 4);
  const upcoming = (matches || [])
    .filter((m) => m.status === "scheduled")
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 4);

  return (
    <div className="px-3 md:px-6">
      {/* بنر لیگ */}
      <section className="mt-6 fade-up">
        <div className="glass-panel relative overflow-hidden px-6 py-14 md:py-20 text-center">
          <div className="absolute inset-0 bg-radial-glow" />
          <div className="relative">
            <div className="mx-auto w-20 h-20 rounded-full bg-gradient-to-br from-gold-light to-gold-dark flex items-center justify-center text-4xl font-black text-obsidian shadow-gold-glow mb-5">
              ا
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold gold-text mb-3">لیگ اتحاد</h1>
            <p className="text-slate-300 max-w-xl mx-auto mb-8">
              خانه‌ی فوتبال محلی؛ جدول زنده، نتایج، گلزنان و آخرین اخبار تیم‌های لیگ اتحاد
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Link href="/standings" className="btn-gold">مشاهده جدول لیگ</Link>
              <Link href="/matches" className="btn-outline">مسابقات</Link>
            </div>
          </div>
        </div>
      </section>

      {/* آخرین نتایج */}
      <section className="mt-12">
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">آخرین نتایج</h2>
          <Link href="/matches" className="text-sm text-gold-light hover:underline">همه مسابقات ←</Link>
        </div>
        {matches === null ? (
          <Spinner />
        ) : results.length === 0 ? (
          <EmptyState title="هنوز نتیجه‌ای ثبت نشده" hint="به محض ثبت اولین مسابقه، نتایج اینجا نمایش داده می‌شود." />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {results.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
      </section>

      {/* مسابقات آینده */}
      <section className="mt-12">
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">مسابقات آینده</h2>
          <Link href="/matches" className="text-sm text-gold-light hover:underline">همه مسابقات ←</Link>
        </div>
        {matches === null ? (
          <Spinner />
        ) : upcoming.length === 0 ? (
          <EmptyState title="مسابقه‌ی آینده‌ای برنامه‌ریزی نشده" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {upcoming.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
      </section>

      {/* اخبار و اطلاعیه‌ها */}
      <section className="mt-12 mb-16">
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">اخبار و اطلاعیه‌ها</h2>
          <Link href="/news" className="text-sm text-gold-light hover:underline">همه اخبار ←</Link>
        </div>
        {news === null ? (
          <Spinner />
        ) : news.length === 0 ? (
          <EmptyState title="خبری منتشر نشده" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {news.slice(0, 3).map((n) => (
              <NewsCard key={n.id} item={n} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
