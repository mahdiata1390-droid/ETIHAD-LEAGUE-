"use client";

import { useEffect, useState } from "react";
import { AdminOnly } from "@/components/Guards";
import { listenNews, createNews, deleteNews, uploadImage } from "@/lib/firestore";
import { NewsItem } from "@/lib/types";
import { GlassCard, Spinner } from "@/components/UI";
import { NewsCard } from "@/components/Cards";

export default function AdminNewsPage() {
  return (
    <AdminOnly>
      <NewsManager />
    </AdminOnly>
  );
}

function NewsManager() {
  const [news, setNews] = useState<NewsItem[] | null>(null);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [type, setType] = useState<"news" | "announcement">("news");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => listenNews(setNews), []);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    setSaving(true);
    try {
      let imageUrl: string | undefined;
      if (imageFile) {
        imageUrl = await uploadImage(imageFile, `news/${Date.now()}-${imageFile.name}`);
      }
      await createNews({ title: title.trim(), body: body.trim(), type, imageUrl });
      setTitle("");
      setBody("");
      setImageFile(null);
      setType("news");
    } finally {
      setSaving(false);
    }
  };

  const onDelete = async (id: string) => {
    if (!confirm("آیا از حذف این خبر مطمئن هستید؟")) return;
    await deleteNews(id);
  };

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">مدیریت اخبار</h1>

      <GlassCard className="mb-8">
        <h2 className="font-bold text-gold-light mb-4">انتشار خبر یا اطلاعیه جدید</h2>
        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setType("news")}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold border ${
                type === "news" ? "bg-gold/15 border-gold text-gold-light" : "border-white/10 text-slate-400"
              }`}
            >
              خبر
            </button>
            <button
              type="button"
              onClick={() => setType("announcement")}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold border ${
                type === "announcement" ? "bg-gold/15 border-gold text-gold-light" : "border-white/10 text-slate-400"
              }`}
            >
              اطلاعیه
            </button>
          </div>
          <input
            className="input-field"
            placeholder="عنوان"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
          <textarea
            className="input-field min-h-[120px]"
            placeholder="متن خبر یا اطلاعیه..."
            value={body}
            onChange={(e) => setBody(e.target.value)}
            required
          />
          <input type="file" accept="image/*" className="input-field" onChange={(e) => setImageFile(e.target.files?.[0] || null)} />
          <button type="submit" disabled={saving} className="btn-gold">
            {saving ? "در حال انتشار..." : "انتشار"}
          </button>
        </form>
      </GlassCard>

      {news === null ? (
        <Spinner />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {news.map((n) => (
            <div key={n.id} className="relative">
              <NewsCard item={n} />
              <button
                onClick={() => onDelete(n.id)}
                className="absolute top-3 left-3 text-xs py-1 px-2.5 rounded-lg border border-red-500/40 text-red-300 bg-obsidian/70 hover:bg-red-500/10"
              >
                حذف
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
