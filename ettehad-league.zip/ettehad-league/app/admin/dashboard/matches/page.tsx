"use client";

import { useEffect, useState } from "react";
import { AdminOnly } from "@/components/Guards";
import { listenTeams, listenMatches, createMatch, deleteMatch, updateMatchSchedule } from "@/lib/firestore";
import { Team, Match } from "@/lib/types";
import { GlassCard, Spinner, TeamLogo, Badge } from "@/components/UI";
import MatchResultForm from "@/components/MatchResultForm";
import { toJalali } from "@/lib/date";

export default function AdminMatchesPage() {
  return (
    <AdminOnly>
      <MatchesManager />
    </AdminOnly>
  );
}

function MatchesManager() {
  const [teams, setTeams] = useState<Team[] | null>(null);
  const [matches, setMatches] = useState<Match[] | null>(null);
  const [homeTeamId, setHomeTeamId] = useState("");
  const [awayTeamId, setAwayTeamId] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [venue, setVenue] = useState("");
  const [saving, setSaving] = useState(false);
  const [resultMatchId, setResultMatchId] = useState<string | null>(null);

  useEffect(() => {
    const u1 = listenTeams(setTeams);
    const u2 = listenMatches(setMatches);
    return () => {
      u1();
      u2();
    };
  }, []);

  const onCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!homeTeamId || !awayTeamId || homeTeamId === awayTeamId || !date || !time) return;
    setSaving(true);
    try {
      const home = teams?.find((t) => t.id === homeTeamId);
      const away = teams?.find((t) => t.id === awayTeamId);
      await createMatch({
        homeTeamId,
        awayTeamId,
        homeTeamName: home?.name || "",
        awayTeamName: away?.name || "",
        homeTeamLogo: home?.logoUrl,
        awayTeamLogo: away?.logoUrl,
        date,
        time,
        venue
      });
      setHomeTeamId("");
      setAwayTeamId("");
      setDate("");
      setTime("");
      setVenue("");
    } finally {
      setSaving(false);
    }
  };

  const onDelete = async (m: Match) => {
    if (!confirm("آیا از حذف این مسابقه مطمئن هستید؟")) return;
    await deleteMatch(m.id);
  };

  const onPostpone = async (m: Match) => {
    await updateMatchSchedule(m.id, { status: m.status === "postponed" ? "scheduled" : "postponed" });
  };

  const resultMatch = matches?.find((m) => m.id === resultMatchId) || null;

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">مدیریت مسابقات</h1>

      <GlassCard className="mb-8">
        <h2 className="font-bold text-gold-light mb-4">ایجاد مسابقه جدید</h2>
        <form onSubmit={onCreate} className="grid sm:grid-cols-2 gap-4">
          <select className="input-field" value={homeTeamId} onChange={(e) => setHomeTeamId(e.target.value)} required>
            <option value="">تیم میزبان</option>
            {(teams || []).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <select className="input-field" value={awayTeamId} onChange={(e) => setAwayTeamId(e.target.value)} required>
            <option value="">تیم مهمان</option>
            {(teams || []).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          <input type="date" className="input-field" value={date} onChange={(e) => setDate(e.target.value)} required />
          <input type="time" className="input-field" value={time} onChange={(e) => setTime(e.target.value)} required />
          <input
            className="input-field sm:col-span-2"
            placeholder="محل برگزاری (مثلاً ورزشگاه آزادی)"
            value={venue}
            onChange={(e) => setVenue(e.target.value)}
          />
          <button type="submit" disabled={saving} className="btn-gold sm:col-span-2">
            {saving ? "در حال ثبت..." : "ایجاد مسابقه"}
          </button>
        </form>
      </GlassCard>

      {resultMatch && (
        <div className="mb-8">
          <MatchResultForm match={resultMatch} onDone={() => setResultMatchId(null)} />
          <button onClick={() => setResultMatchId(null)} className="btn-outline mt-3 w-full">بستن فرم</button>
        </div>
      )}

      {matches === null ? (
        <Spinner />
      ) : (
        <div className="space-y-3">
          {matches.map((m) => (
            <GlassCard key={m.id} className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex items-center gap-3 flex-1">
                <TeamLogo src={m.homeTeamLogo} alt={m.homeTeamName || ""} size={32} />
                <span className="text-sm font-semibold">{m.homeTeamName}</span>
                <span className="text-slate-500 text-xs">
                  {m.status === "finished" ? `${m.homeScore} - ${m.awayScore}` : "vs"}
                </span>
                <span className="text-sm font-semibold">{m.awayTeamName}</span>
                <TeamLogo src={m.awayTeamLogo} alt={m.awayTeamName || ""} size={32} />
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>{toJalali(m.date)} {m.time}</span>
                {m.status === "finished" && <Badge tone="green">پایان یافته</Badge>}
                {m.status === "postponed" && <Badge tone="red">به تعویق افتاد</Badge>}
                {m.status === "scheduled" && <Badge tone="blue">آینده</Badge>}
              </div>
              <div className="flex gap-2 flex-wrap">
                <button onClick={() => setResultMatchId(m.id)} className="btn-outline text-xs py-1.5 px-3">
                  ثبت/ویرایش نتیجه
                </button>
                <button onClick={() => onPostpone(m)} className="btn-outline text-xs py-1.5 px-3">
                  {m.status === "postponed" ? "لغو تعویق" : "تعویق مسابقه"}
                </button>
                <button
                  onClick={() => onDelete(m)}
                  className="text-xs py-1.5 px-3 rounded-lg border border-red-500/40 text-red-300 hover:bg-red-500/10"
                >
                  حذف
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
