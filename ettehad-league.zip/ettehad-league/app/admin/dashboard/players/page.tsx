"use client";

import { useEffect, useState } from "react";
import { AdminOnly } from "@/components/Guards";
import {
  listenTeams,
  listenPlayers,
  createPlayer,
  updatePlayer,
  deletePlayer,
  uploadImage,
  linkPlayerAccount,
  unlinkPlayerAccount
} from "@/lib/firestore";
import { Player, PlayerPosition, Team } from "@/lib/types";
import { PlayerPhoto, GlassCard, Spinner } from "@/components/UI";

const positions: PlayerPosition[] = ["دروازه‌بان", "مدافع", "هافبک", "مهاجم"];

export default function AdminPlayersPage() {
  return (
    <AdminOnly>
      <PlayersManager />
    </AdminOnly>
  );
}

function PlayersManager() {
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [teams, setTeams] = useState<Team[] | null>(null);
  const [editing, setEditing] = useState<Player | null>(null);
  const [name, setName] = useState("");
  const [teamId, setTeamId] = useState("");
  const [shirtNumber, setShirtNumber] = useState("");
  const [position, setPosition] = useState<PlayerPosition>("مهاجم");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const u1 = listenPlayers(setPlayers);
    const u2 = listenTeams(setTeams);
    return () => {
      u1();
      u2();
    };
  }, []);

  const resetForm = () => {
    setEditing(null);
    setName("");
    setTeamId("");
    setShirtNumber("");
    setPosition("مهاجم");
    setPhotoFile(null);
  };

  const startEdit = (p: Player) => {
    setEditing(p);
    setName(p.name);
    setTeamId(p.teamId);
    setShirtNumber(String(p.shirtNumber));
    setPosition(p.position);
    setPhotoFile(null);
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !teamId || !shirtNumber) return;
    setSaving(true);
    try {
      let photoUrl = editing?.photoUrl;
      if (photoFile) {
        photoUrl = await uploadImage(photoFile, `players/${Date.now()}-${photoFile.name}`);
      }
      const team = teams?.find((t) => t.id === teamId);
      const payload = {
        name: name.trim(),
        teamId,
        teamName: team?.name || "",
        shirtNumber: Number(shirtNumber),
        position,
        photoUrl
      };
      if (editing) {
        await updatePlayer(editing.id, payload);
      } else {
        await createPlayer(payload as any);
      }
      resetForm();
    } finally {
      setSaving(false);
    }
  };

  const onDelete = async (p: Player) => {
    if (!confirm(`آیا از حذف بازیکن «${p.name}» مطمئن هستید؟`)) return;
    await deletePlayer(p.id);
  };

  const [linkUidInputs, setLinkUidInputs] = useState<Record<string, string>>({});

  const onLink = async (p: Player) => {
    const uid = linkUidInputs[p.id]?.trim();
    if (!uid) return;
    await linkPlayerAccount(uid, p.id);
    setLinkUidInputs((prev) => ({ ...prev, [p.id]: "" }));
  };

  const onUnlink = async (p: Player) => {
    if (!p.authUid) return;
    if (!confirm("اتصال حساب این بازیکن قطع شود؟")) return;
    await unlinkPlayerAccount(p.authUid, p.id);
  };

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">مدیریت بازیکنان</h1>

      <GlassCard className="mb-8">
        <h2 className="font-bold text-gold-light mb-4">{editing ? "ویرایش بازیکن" : "افزودن بازیکن جدید"}</h2>
        <form onSubmit={onSubmit} className="grid sm:grid-cols-2 gap-4">
          <input
            className="input-field"
            placeholder="نام بازیکن"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <select className="input-field" value={teamId} onChange={(e) => setTeamId(e.target.value)} required>
            <option value="">انتخاب تیم</option>
            {(teams || []).map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
          <input
            className="input-field"
            placeholder="شماره پیراهن"
            type="number"
            value={shirtNumber}
            onChange={(e) => setShirtNumber(e.target.value)}
            required
          />
          <select
            className="input-field"
            value={position}
            onChange={(e) => setPosition(e.target.value as PlayerPosition)}
          >
            {positions.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
          <input
            className="input-field sm:col-span-2"
            type="file"
            accept="image/*"
            onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
          />
          <div className="sm:col-span-2 flex gap-3">
            <button type="submit" disabled={saving} className="btn-gold">
              {saving ? "در حال ذخیره..." : editing ? "ذخیره تغییرات" : "افزودن بازیکن"}
            </button>
            {editing && (
              <button type="button" onClick={resetForm} className="btn-outline">
                انصراف
              </button>
            )}
          </div>
        </form>
      </GlassCard>

      {players === null ? (
        <Spinner />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {players.map((p) => (
            <GlassCard key={p.id}>
              <div className="flex items-center gap-3 mb-3">
                <PlayerPhoto src={p.photoUrl} alt={p.name} size={48} />
                <div className="flex-1 min-w-0">
                  <p className="font-bold truncate text-sm">{p.name}</p>
                  <p className="text-xs text-slate-400">{p.teamName} · {p.position} · #{p.shirtNumber}</p>
                </div>
                <div className="flex flex-col gap-1.5">
                  <button onClick={() => startEdit(p)} className="btn-outline py-1 px-2.5 text-xs">
                    ویرایش
                  </button>
                  <button
                    onClick={() => onDelete(p)}
                    className="py-1 px-2.5 text-xs rounded-lg border border-red-500/40 text-red-300 hover:bg-red-500/10"
                  >
                    حذف
                  </button>
                </div>
              </div>
              <div className="pt-3 border-t border-white/10">
                {p.authUid ? (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-emerald-400">✓ حساب متصل است</span>
                    <button onClick={() => onUnlink(p)} className="text-xs text-red-300 hover:underline">
                      قطع اتصال
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      className="input-field text-xs py-1.5"
                      placeholder="UID حساب Firebase بازیکن"
                      dir="ltr"
                      value={linkUidInputs[p.id] || ""}
                      onChange={(e) => setLinkUidInputs((prev) => ({ ...prev, [p.id]: e.target.value }))}
                    />
                    <button onClick={() => onLink(p)} className="btn-outline text-xs py-1.5 px-3 shrink-0">
                      اتصال
                    </button>
                  </div>
                )}
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
