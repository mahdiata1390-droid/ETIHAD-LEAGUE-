"use client";

import { useEffect, useState } from "react";
import { AdminOnly } from "@/components/Guards";
import {
  listenTeams,
  createTeam,
  updateTeam,
  deleteTeam,
  uploadImage
} from "@/lib/firestore";
import { Team } from "@/lib/types";
import { TeamLogo, GlassCard, Spinner } from "@/components/UI";

export default function AdminTeamsPage() {
  return (
    <AdminOnly>
      <TeamsManager />
    </AdminOnly>
  );
}

function TeamsManager() {
  const [teams, setTeams] = useState<Team[] | null>(null);
  const [editing, setEditing] = useState<Team | null>(null);
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [foundedYear, setFoundedYear] = useState("");
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => listenTeams(setTeams), []);

  const resetForm = () => {
    setEditing(null);
    setName("");
    setCity("");
    setFoundedYear("");
    setLogoFile(null);
  };

  const startEdit = (t: Team) => {
    setEditing(t);
    setName(t.name);
    setCity(t.city || "");
    setFoundedYear(t.foundedYear ? String(t.foundedYear) : "");
    setLogoFile(null);
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    try {
      let logoUrl = editing?.logoUrl;
      if (logoFile) {
        logoUrl = await uploadImage(logoFile, `teams/${Date.now()}-${logoFile.name}`);
      }
      if (editing) {
        await updateTeam(editing.id, {
          name: name.trim(),
          city: city.trim(),
          foundedYear: foundedYear ? Number(foundedYear) : undefined,
          logoUrl
        });
      } else {
        await createTeam({
          name: name.trim(),
          city: city.trim(),
          foundedYear: foundedYear ? Number(foundedYear) : undefined,
          logoUrl
        });
      }
      resetForm();
    } finally {
      setSaving(false);
    }
  };

  const onDelete = async (t: Team) => {
    if (!confirm(`آیا از حذف تیم «${t.name}» مطمئن هستید؟`)) return;
    await deleteTeam(t.id);
  };

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">مدیریت تیم‌ها</h1>

      <GlassCard className="mb-8">
        <h2 className="font-bold text-gold-light mb-4">{editing ? "ویرایش تیم" : "افزودن تیم جدید"}</h2>
        <form onSubmit={onSubmit} className="grid sm:grid-cols-2 gap-4">
          <input
            className="input-field"
            placeholder="نام تیم"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <input
            className="input-field"
            placeholder="شهر (اختیاری)"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <input
            className="input-field"
            placeholder="سال تأسیس (اختیاری)"
            type="number"
            value={foundedYear}
            onChange={(e) => setFoundedYear(e.target.value)}
          />
          <input
            className="input-field file:ml-3 file:btn-outline file:border-0 file:cursor-pointer"
            type="file"
            accept="image/*"
            onChange={(e) => setLogoFile(e.target.files?.[0] || null)}
          />
          <div className="sm:col-span-2 flex gap-3">
            <button type="submit" disabled={saving} className="btn-gold">
              {saving ? "در حال ذخیره..." : editing ? "ذخیره تغییرات" : "افزودن تیم"}
            </button>
            {editing && (
              <button type="button" onClick={resetForm} className="btn-outline">
                انصراف
              </button>
            )}
          </div>
        </form>
      </GlassCard>

      {teams === null ? (
        <Spinner />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {teams.map((t) => (
            <GlassCard key={t.id} className="flex items-center gap-4">
              <TeamLogo src={t.logoUrl} alt={t.name} size={52} />
              <div className="flex-1 min-w-0">
                <p className="font-bold truncate">{t.name}</p>
                {t.city && <p className="text-xs text-slate-400">{t.city}</p>}
              </div>
              <div className="flex gap-2">
                <button onClick={() => startEdit(t)} className="btn-outline py-1.5 px-3 text-xs">
                  ویرایش
                </button>
                <button
                  onClick={() => onDelete(t)}
                  className="py-1.5 px-3 text-xs rounded-lg border border-red-500/40 text-red-300 hover:bg-red-500/10"
                >
                  حذف
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
