"use client";

import Link from "next/link";
import { AdminOnly } from "@/components/Guards";
import { GlassCard } from "@/components/UI";

const sections = [
  { href: "/admin/dashboard/teams", title: "مدیریت تیم‌ها", desc: "افزودن، ویرایش و حذف تیم و لوگو", icon: "🛡️" },
  { href: "/admin/dashboard/players", title: "مدیریت بازیکنان", desc: "افزودن، ویرایش و حذف بازیکن و عکس", icon: "👤" },
  { href: "/admin/dashboard/matches", title: "مدیریت مسابقات", desc: "ایجاد مسابقه و ثبت نتیجه، گل و کارت", icon: "⚽" },
  { href: "/admin/dashboard/news", title: "مدیریت اخبار", desc: "انتشار خبر و اطلاعیه", icon: "📰" }
];

export default function AdminDashboard() {
  return (
    <AdminOnly>
      <div className="px-3 md:px-6 py-8">
        <h1 className="section-title mb-6">پنل مدیریت لیگ اتحاد</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {sections.map((s) => (
            <Link key={s.href} href={s.href}>
              <GlassCard className="hover:border-gold/50 transition-colors h-full">
                <div className="flex items-start gap-4">
                  <span className="text-3xl">{s.icon}</span>
                  <div>
                    <p className="font-bold text-lg text-slate-100">{s.title}</p>
                    <p className="text-sm text-slate-400 mt-1">{s.desc}</p>
                  </div>
                </div>
              </GlassCard>
            </Link>
          ))}
        </div>
      </div>
    </AdminOnly>
  );
}
