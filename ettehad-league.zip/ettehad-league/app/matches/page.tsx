"use client";

import { useEffect, useState } from "react";
import { listenMatches } from "@/lib/firestore";
import { Match, MatchStatus } from "@/lib/types";
import MatchCard from "@/components/MatchCard";
import { Spinner, EmptyState } from "@/components/UI";

const filters: { key: MatchStatus | "all"; label: string }[] = [
  { key: "all", label: "همه" },
  { key: "scheduled", label: "آینده" },
  { key: "finished", label: "پایان‌یافته" },
  { key: "postponed", label: "به‌تعویق‌افتاده" }
];

export default function MatchesPage() {
  const [matches, setMatches] = useState<Match[] | null>(null);
  const [filter, setFilter] = useState<MatchStatus | "all">("all");

  useEffect(() => listenMatches(setMatches), []);

  const filtered = (matches || []).filter((m) => filter === "all" || m.status === filter);

  return (
    <div className="px-3 md:px-6 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <h1 className="section-title">مسابقات</h1>
        <div className="flex gap-2 flex-wrap">
          {filters.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
                filter === f.key
                  ? "bg-gold/15 border-gold text-gold-light"
                  : "border-white/10 text-slate-400 hover:border-gold/30"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {matches === null ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <EmptyState title="مسابقه‌ای یافت نشد" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((m) => (
            <MatchCard key={m.id} match={m} />
          ))}
        </div>
      )}
    </div>
  );
}
