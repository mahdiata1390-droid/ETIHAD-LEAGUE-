"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { getMatch } from "@/lib/firestore";
import { Match } from "@/lib/types";
import { TeamLogo, Spinner, EmptyState, GlassCard, Badge } from "@/components/UI";
import { toJalali } from "@/lib/date";

export default function MatchDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [match, setMatch] = useState<Match | null | undefined>(undefined);

  useEffect(() => {
    getMatch(id).then(setMatch);
  }, [id]);

  if (match === undefined) return <Spinner />;
  if (match === null) return <EmptyState title="مسابقه یافت نشد" />;

  const finished = match.status === "finished";

  return (
    <div className="px-3 md:px-6 py-8 max-w-3xl mx-auto">
      <div className="glass-panel p-8 mb-8 fade-up">
        <div className="flex justify-center mb-4">
          {finished ? (
            <Badge tone="green">پایان یافته</Badge>
          ) : match.status === "postponed" ? (
            <Badge tone="red">به تعویق افتاد</Badge>
          ) : (
            <Badge tone="blue">آینده</Badge>
          )}
        </div>
        <div className="flex items-center justify-between">
          <div className="flex flex-col items-center gap-2 w-1/3">
            <TeamLogo src={match.homeTeamLogo} alt={match.homeTeamName || ""} size={72} />
            <span className="font-bold text-center">{match.homeTeamName}</span>
          </div>
          <div className="text-center w-1/3">
            {finished ? (
              <div className="text-4xl font-extrabold gold-text">
                {match.homeScore} - {match.awayScore}
              </div>
            ) : (
              <div className="text-2xl font-bold text-slate-400">VS</div>
            )}
          </div>
          <div className="flex flex-col items-center gap-2 w-1/3">
            <TeamLogo src={match.awayTeamLogo} alt={match.awayTeamName || ""} size={72} />
            <span className="font-bold text-center">{match.awayTeamName}</span>
          </div>
        </div>
        <div className="text-center text-sm text-slate-400 mt-6 space-y-1">
          <p>{toJalali(match.date)} — ساعت {match.time}</p>
          {match.venue && <p>📍 {match.venue}</p>}
        </div>
      </div>

      {finished && (
        <div className="grid sm:grid-cols-2 gap-6">
          <GlassCard>
            <h3 className="font-bold text-gold-light mb-3">⚽ گلزنان</h3>
            {match.goals?.length ? (
              <ul className="space-y-2 text-sm">
                {match.goals.map((g, i) => (
                  <li key={i} className="flex justify-between text-slate-300">
                    <span>{g.playerName}{g.assistPlayerName ? ` (پاس: ${g.assistPlayerName})` : ""}</span>
                    {g.minute && <span className="text-slate-500">'{g.minute}</span>}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-500">گلی ثبت نشده</p>
            )}
          </GlassCard>

          <GlassCard>
            <h3 className="font-bold text-gold-light mb-3">🟨🟥 کارت‌ها</h3>
            {match.cards?.length ? (
              <ul className="space-y-2 text-sm">
                {match.cards.map((c, i) => (
                  <li key={i} className="flex justify-between text-slate-300">
                    <span>{c.type === "yellow" ? "🟨" : "🟥"} {c.playerName}</span>
                    {c.minute && <span className="text-slate-500">'{c.minute}</span>}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-500">کارتی ثبت نشده</p>
            )}
          </GlassCard>

          {match.manOfTheMatchName && (
            <GlassCard className="sm:col-span-2 text-center">
              <h3 className="font-bold text-gold-light mb-2">🏅 بهترین بازیکن مسابقه</h3>
              <p className="text-lg font-bold">{match.manOfTheMatchName}</p>
            </GlassCard>
          )}
        </div>
      )}
    </div>
  );
}
