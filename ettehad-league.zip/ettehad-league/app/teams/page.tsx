"use client";

import { useEffect, useState } from "react";
import { listenTeams } from "@/lib/firestore";
import { Team } from "@/lib/types";
import { TeamCard } from "@/components/Cards";
import { Spinner, EmptyState } from "@/components/UI";

export default function TeamsPage() {
  const [teams, setTeams] = useState<Team[] | null>(null);

  useEffect(() => listenTeams(setTeams), []);

  return (
    <div className="px-3 md:px-6 py-8">
      <h1 className="section-title mb-6">تیم‌های لیگ اتحاد</h1>
      {teams === null ? (
        <Spinner />
      ) : teams.length === 0 ? (
        <EmptyState title="هنوز تیمی ثبت نشده" />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {teams.map((t) => (
            <TeamCard key={t.id} team={t} />
          ))}
        </div>
      )}
    </div>
  );
}
