"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { getTeam, listenPlayers, listenMatches, listenTeams } from "@/lib/firestore";
import { computeStandings } from "@/lib/standings";
import { Team, Player, Match } from "@/lib/types";
import { TeamLogo, Spinner, EmptyState, GlassCard } from "@/components/UI";
import { PlayerCard } from "@/components/Cards";
import MatchCard from "@/components/MatchCard";

export default function TeamDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [team, setTeam] = useState<Team | null | undefined>(undefined);
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [allTeams, setAllTeams] = useState<Team[] | null>(null);
  const [matches, setMatches] = useState<Match[] | null>(null);

  useEffect(() => {
    getTeam(id).then(setTeam);
    const u1 = listenPlayers(setPlayers, id);
    const u2 = listenMatches(setMatches);
    const u3 = listenTeams(setAllTeams);
    return () => {
      u1();
      u2();
      u3();
    };
  }, [id]);

  if (team === undefined || players === null || matches === null || allTeams === null) {
    return <Spinner />;
  }
  if (team === null) {
    return <EmptyState title="تیم یافت نشد" />;
  }

  const teamMatches = matches
    .filter((m) => m.homeTeamId === id || m.awayTeamId === id)
    .sort((a, b) => b.date.localeCompare(a.date));

  const stats = computeStandings(allTeams, matches).find((r) => r.teamId === id);

  return (
    <div className="px-3 md:px-6 py-8">
      <div className="glass-panel p-8 flex flex-col md:flex-row items-center gap-6 mb-10 fade-up">
        <TeamLogo src={team.logoUrl} alt={team.name} size={100} />
        <div className="text-center md:text-right flex-1">
          <h1 className="text-2xl md:text-3xl font-extrabold gold-text mb-1">{team.name}</h1>
          {team.city && <p className="text-slate-400 text-sm">{team.city}</p>}
        </div>
        {stats && (
          <div className="grid grid-cols-4 gap-4 text-center">
            <StatBox label="بازی" value={stats.played} />
            <StatBox label="برد" value={stats.won} />
            <StatBox label="امتیاز" value={stats.points} gold />
            <StatBox label="تفاضل گل" value={stats.goalDiff} />
          </div>
        )}
      </div>

      <section className="mb-10">
        <h2 className="section-title mb-4">بازیکنان</h2>
        {players.length === 0 ? (
          <EmptyState title="بازیکنی برای این تیم ثبت نشده" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {players.map((p) => (
              <PlayerCard key={p.id} player={p} />
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="section-title mb-4">آخرین مسابقات</h2>
        {teamMatches.length === 0 ? (
          <EmptyState title="مسابقه‌ای ثبت نشده" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {teamMatches.slice(0, 6).map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function StatBox({ label, value, gold }: { label: string; value: number; gold?: boolean }) {
  return (
    <GlassCard className="p-3">
      <p className={`text-xl font-extrabold ${gold ? "gold-text" : "text-slate-100"}`}>{value}</p>
      <p className="text-xs text-slate-400 mt-0.5">{label}</p>
    </GlassCard>
  );
}
