"use client";

import { useEffect, useState } from "react";
import { listenPlayers, listenTeams } from "@/lib/firestore";
import { Player, Team } from "@/lib/types";
import { PlayerCard } from "@/components/Cards";
import { Spinner, EmptyState } from "@/components/UI";

export default function PlayersPage() {
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [teams, setTeams] = useState<Team[] | null>(null);
  const [teamFilter, setTeamFilter] = useState<string>("all");

  useEffect(() => {
    const u1 = listenPlayers(setPlayers);
    const u2 = listenTeams(setTeams);
    return () => {
      u1();
      u2();
    };
  }, []);

  const filtered = (players || []).filter((p) => teamFilter === "all" || p.teamId === teamFilter);

  return (
    <div className="px-3 md:px-6 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <h1 className="section-title">بازیکنان</h1>
        <select
          value={teamFilter}
          onChange={(e) => setTeamFilter(e.target.value)}
          className="input-field sm:w-64"
        >
          <option value="all">همه تیم‌ها</option>
          {(teams || []).map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </div>

      {players === null ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <EmptyState title="بازیکنی یافت نشد" />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((p) => (
            <PlayerCard key={p.id} player={p} />
          ))}
        </div>
      )}
    </div>
  );
}
