"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { getPlayer } from "@/lib/firestore";
import { Player } from "@/lib/types";
import { PlayerPhoto, Spinner, EmptyState, GlassCard } from "@/components/UI";

export default function PlayerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [player, setPlayer] = useState<Player | null | undefined>(undefined);

  useEffect(() => {
    getPlayer(id).then(setPlayer);
  }, [id]);

  if (player === undefined) return <Spinner />;
  if (player === null) return <EmptyState title="بازیکن یافت نشد" />;

  const s = player.stats;

  return (
    <div className="px-3 md:px-6 py-8 max-w-3xl mx-auto">
      <div className="glass-panel p-8 flex flex-col sm:flex-row items-center gap-6 mb-8 fade-up">
        <PlayerPhoto src={player.photoUrl} alt={player.name} size={110} />
        <div className="text-center sm:text-right flex-1">
          <h1 className="text-2xl font-extrabold gold-text mb-1">{player.name}</h1>
          <p className="text-slate-400 text-sm">{player.teamName} · {player.position}</p>
        </div>
        <div className="w-14 h-14 rounded-full bg-gold/10 border border-gold/30 flex items-center justify-center font-extrabold text-gold-light text-xl">
          {player.shirtNumber}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <StatBox label="بازی" value={s.matches} />
        <StatBox label="گل" value={s.goals} gold />
        <StatBox label="پاس گل" value={s.assists} />
        <StatBox label="کارت زرد" value={s.yellowCards} tone="yellow" />
        <StatBox label="کارت قرمز" value={s.redCards} tone="red" />
      </div>
    </div>
  );
}

function StatBox({
  label,
  value,
  gold,
  tone
}: {
  label: string;
  value: number;
  gold?: boolean;
  tone?: "yellow" | "red";
}) {
  const color = gold
    ? "gold-text"
    : tone === "yellow"
    ? "text-yellow-400"
    : tone === "red"
    ? "text-red-400"
    : "text-slate-100";
  return (
    <GlassCard className="text-center p-4">
      <p className={`text-2xl font-extrabold ${color}`}>{value}</p>
      <p className="text-xs text-slate-400 mt-1">{label}</p>
    </GlassCard>
  );
}
