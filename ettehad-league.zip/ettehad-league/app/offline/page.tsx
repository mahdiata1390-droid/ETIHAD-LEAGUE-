export default function OfflinePage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="glass-panel p-10 text-center max-w-sm">
        <div className="text-4xl mb-4">📡</div>
        <h1 className="section-title mb-2">اتصال اینترنت برقرار نیست</h1>
        <p className="text-slate-400 text-sm">
          به نظر می‌رسد آفلاین هستید. برخی صفحاتی که قبلاً بازدید کرده‌اید همچنان در دسترس‌اند.
        </p>
      </div>
    </div>
  );
}
