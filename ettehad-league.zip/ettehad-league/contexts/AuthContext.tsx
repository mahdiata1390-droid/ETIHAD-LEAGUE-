"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode
} from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  User
} from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

interface AuthContextValue {
  user: User | null;
  role: "admin" | "player" | null;
  playerId: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  role: null,
  playerId: null,
  loading: true,
  login: async () => {},
  logout: async () => {}
});

// UID مدیر از متغیر محیطی خوانده می‌شود تا هیچ‌جای کد و سایت اسم/ایمیل مدیر نمایش داده نشود.
const ADMIN_UID = process.env.NEXT_PUBLIC_ADMIN_UID;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<"admin" | "player" | null>(null);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (!u) {
        setRole(null);
        setPlayerId(null);
        setLoading(false);
        return;
      }

      if (ADMIN_UID && u.uid === ADMIN_UID) {
        setRole("admin");
        setPlayerId(null);
        setLoading(false);
        return;
      }

      // در غیر این صورت به دنبال بازیکنی می‌گردیم که authUid برابر این کاربر باشد
      try {
        const snap = await getDoc(doc(db, "playerLinks", u.uid));
        if (snap.exists()) {
          setRole("player");
          setPlayerId((snap.data() as any).playerId);
        } else {
          setRole(null);
          setPlayerId(null);
        }
      } catch {
        setRole(null);
        setPlayerId(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const login = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const logout = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, role, playerId, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
