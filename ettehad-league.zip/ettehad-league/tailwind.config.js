/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        obsidian: "#0a0e17",
        "obsidian-2": "#0f1524",
        "navy-deep": "#101c35",
        "navy-mid": "#152a4e",
        gold: {
          DEFAULT: "#d4af37",
          light: "#f0d878",
          dark: "#9c7d1f"
        },
        glass: "rgba(255,255,255,0.06)",
        "glass-border": "rgba(212,175,55,0.25)"
      },
      fontFamily: {
        vazir: ["var(--font-vazir)", "Tahoma", "sans-serif"]
      },
      backgroundImage: {
        "radial-glow": "radial-gradient(circle at 50% 0%, rgba(212,175,55,0.15), transparent 60%)",
        "navy-gradient": "linear-gradient(160deg, #0a0e17 0%, #101c35 45%, #0f1524 100%)"
      },
      boxShadow: {
        glass: "0 8px 32px rgba(0,0,0,0.45)",
        "gold-glow": "0 0 24px rgba(212,175,55,0.35)"
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: 0, transform: "translateY(16px)" },
          "100%": { opacity: 1, transform: "translateY(0)" }
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" }
        }
      },
      animation: {
        fadeUp: "fadeUp 0.6s ease forwards",
        shimmer: "shimmer 2.5s linear infinite"
      }
    }
  },
  plugins: []
};
